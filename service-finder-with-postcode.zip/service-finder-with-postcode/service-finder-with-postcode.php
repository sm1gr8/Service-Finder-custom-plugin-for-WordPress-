<?php
/*
Plugin Name: Service Finder with Postcode
Description: Check service availability by postcode using CSV.
Version: 2.1
Author: Sharjeel Abbas
*/

if (!defined('ABSPATH')) exit;

// Enqueue admin assets
function sfwp_enqueue_admin_assets($hook) {
    if ($hook !== 'toplevel_page_service-finder') return;
    wp_enqueue_style('sfwp-admin-style', plugin_dir_url(__FILE__) . 'css/sfwp-admin.css', array(), '2.0');
    wp_enqueue_script('sfwp-admin-script', plugin_dir_url(__FILE__) . 'js/sfwp-admin.js', array('jquery'), '2.0', true);
    wp_localize_script('sfwp-admin-script', 'sfwpData', array(
        'postcodes' => get_option('sfwp_postcodes', array()),
        'nonce' => wp_create_nonce('sfwp_preview_nonce')
    ));
}
add_action('admin_enqueue_scripts', 'sfwp_enqueue_admin_assets');

// Enqueue frontend assets
function sfwp_enqueue_advanced_frontend_assets() {
    wp_enqueue_style('fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css', array(), '6.4.2');
    wp_enqueue_style('sfwp-frontend-style', plugin_dir_url(__FILE__) . 'css/sfwp-frontend.css', array(), '1.0');
    wp_enqueue_script('sfwp-frontend-js', plugin_dir_url(__FILE__) . 'js/sfwp-frontend.js', array('jquery'), '1.0', true);
    wp_localize_script('sfwp-frontend-js', 'sfwpAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('sfwp_frontend_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'sfwp_enqueue_advanced_frontend_assets');

// Admin Menu
function sfwp_admin_menu() {
    add_menu_page('Service Finder Settings', 'Service Finder', 'manage_options', 'service-finder', 'sfwp_admin_page', 'dashicons-upload');
}
add_action('admin_menu', 'sfwp_admin_menu');

// CSV Upload or Clear Handler
add_action('admin_init', function () {
    if (!current_user_can('manage_options')) return;

    // Handle upload
    if (isset($_POST['sfwp_upload_csv']) && check_admin_referer('sfwp_upload_csv_action')) {
        if (!empty($_FILES['sfwp_csv_file']['tmp_name'])) {
            $rows = array_map('str_getcsv', file($_FILES['sfwp_csv_file']['tmp_name']));
            $postcodes = [];

            foreach ($rows as $index => $row) {
                if ($index === 0) continue; // skip header
                if (!empty($row[0])) {
                    $postcodes[] = sanitize_text_field(trim($row[0]));
                }
            }

            update_option('sfwp_postcodes', array_unique($postcodes));
            add_settings_error('sfwp_messages', 'sfwp_csv_success', count($postcodes) . ' postcodes imported.', 'updated');
        } else {
            add_settings_error('sfwp_messages', 'sfwp_csv_fail', 'Upload failed. No file selected.', 'error');
        }
    }

    // Handle clear
    if (isset($_POST['sfwp_clear_csv']) && check_admin_referer('sfwp_upload_csv_action')) {
        delete_option('sfwp_postcodes');
        add_settings_error('sfwp_messages', 'sfwp_csv_cleared', 'Postcodes cleared successfully.', 'updated');
    }
});

// Save Settings
function sfwp_save_cta_settings() {
    if (!current_user_can('manage_options')) return;
    if (isset($_POST['sfwp_save_cta']) && check_admin_referer('sfwp_save_cta_action')) {
        $settings = array(
            'cta_text' => sanitize_text_field($_POST['sfwp_cta_text'] ?? ''),
            'cta_type' => sanitize_text_field($_POST['sfwp_cta_type'] ?? ''),
            'cta_value' => sanitize_text_field($_POST['sfwp_cta_value'] ?? ''),
            'cta_custom_class' => sanitize_text_field($_POST['sfwp_cta_custom_class'] ?? ''),
            'success_message_html' => wp_kses_post($_POST['sfwp_success_message_html'] ?? '<p>We have experts in {(sfwp_postcode)}</p>')
        );

        $services_raw = $_POST['sfwp_services'] ?? array();
        $services = array();

        foreach ($services_raw as $service) {
            $services[] = array(
                'icon_or_image' => wp_kses_post($service['icon_or_image'] ?? ''),  // Allow HTML (FontAwesome)
                'name' => sanitize_text_field($service['name'] ?? '')
            );
        }

        update_option('sfwp_cta_settings', $settings);
        update_option('sfwp_dynamic_services', $services);

        add_settings_error('sfwp_messages', 'sfwp_message', 'Settings saved successfully!', 'updated');
    }
}

add_action('admin_init', 'sfwp_save_cta_settings');


// CSV Download
function sfwp_handle_csv_download() {
    if (!current_user_can('manage_options')) wp_die('Access denied.');
    if (!isset($_GET['nonce']) || !wp_verify_nonce($_GET['nonce'], 'sfwp_download_nonce')) wp_die('Security check failed.');
    $postcodes = get_option('sfwp_postcodes', array());
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="postcodes.csv"');
    header('Pragma: no-cache');
    header('Expires: 0');
    $output = fopen('php://output', 'w');
    fputcsv($output, array('postcode'));
    foreach ($postcodes as $postcode) fputcsv($output, array($postcode));
    fclose($output);
    exit;
}
add_action('admin_post_sfwp_download_csv', 'sfwp_handle_csv_download');

// CTA Button Renderer
function sfwp_get_cta_button_html() {
    $settings = get_option('sfwp_cta_settings', array());
    $text = $settings['cta_text'] ?? 'Get in Touch';
    $type = $settings['cta_type'] ?? '';
    $value = $settings['cta_value'] ?? '';
    $custom_class = $settings['cta_custom_class'] ?? '';
    $class_attr = 'btn btn-md ' . esc_attr($custom_class);

    if ($type === 'url') {
        return '<a class="' . $class_attr . '" href="' . esc_url($value) . '">' . esc_html($text) . '</a>';
    } elseif ($type === 'popup') {
        $popup_number = preg_replace('/\D/', '', $value);
        return '<a href="javascript:;" class="' . $class_attr . ' ' . esc_attr($value) . '" data-popup="' . esc_attr($popup_number) . '" data-settings="[object Object]">' . esc_html($text) . '</a>';
    } elseif ($type === 'avada') {
        return '<a href="#' . esc_attr(ltrim($value, '#')) . '" class="' . $class_attr . '">' . esc_html($text) . '</a>';
    } else {
        return '<a class="' . $class_attr . '" href="/contact-us">' . esc_html($text) . '</a>';
    }
}

// Admin Page
function sfwp_admin_page() {
    $cta_settings = get_option('sfwp_cta_settings', array(
        'cta_text' => 'Get in Touch',
        'cta_type' => 'url',
        'cta_value' => '/contact-us',
        'cta_custom_class' => '',
        'success_message_html' => '<p>Great! Experts in {(sfwp_postcode)}</p>'
    ));
    $postcodes = get_option('sfwp_postcodes', array());
    $preview_count = min(10, count($postcodes));
    $download_url = admin_url('admin-post.php?action=sfwp_download_csv&nonce=' . wp_create_nonce('sfwp_download_nonce'));
    ?>
    <div class="wrap">
        <h1>Service Finder</h1>
        <?php settings_errors('sfwp_messages'); ?>

        <form method="post" enctype="multipart/form-data" style="margin-bottom: 20px;">
    <?php wp_nonce_field('sfwp_upload_csv_action'); ?>
    <input type="file" name="sfwp_csv_file" accept=".csv" />
    <input type="submit" name="sfwp_upload_csv" class="button button-primary" value="Upload CSV" />
    <input type="submit" name="sfwp_clear_csv" class="button button-secondary" value="Clear Data" onclick="return confirm('Are you sure you want to clear all postcode data?');" />
</form>


        <?php if (!empty($postcodes)): ?>
            <div class="sfwp-preview-section">
                <h2>Preview Data</h2>
                <p class="description">You can clear this data or replace it by uploading a new CSV file above. Don't forget to hit <strong>Save Settings</strong> after changes.</p>
                <ul class="sfwp-sample-list">
                    <?php for ($i = 0; $i < $preview_count; $i++): ?>
                        <li><?php echo esc_html($postcodes[$i]); ?></li>
                    <?php endfor; ?>
                </ul>
                <p><?php echo count($postcodes); ?> rows / 1 headers</p>
                <div class="download-CSV">
                    <a href="<?php echo esc_url($download_url); ?>" class="button button-secondary" target="_blank">Download CSV</a>
                </div>
                <button id="sfwp-preview-all-btn" class="button">Preview All Data</button>
            </div>

            <div id="sfwp-modal" class="sfwp-modal">
                <div class="sfwp-modal-content">
                    <span class="sfwp-close">&times;</span>
                    <input type="text" id="sfwp-search" placeholder="Search postcode..." />
                    <ul id="sfwp-list"></ul>
                    <div id="sfwp-pagination"></div>
                </div>
            </div>
        <?php endif; ?>

        <h2>Success Button Settings</h2>
        <form method="post">
            <?php wp_nonce_field('sfwp_save_cta_action'); ?>
            <p><label>Button Text:<br><input type="text" name="sfwp_cta_text" value="<?php echo esc_attr($cta_settings['cta_text']); ?>" class="regular-text" /></label></p>
            <p><label>Button Type:<br>
                <select name="sfwp_cta_type">
                    <option value="url" <?php selected($cta_settings['cta_type'], 'url'); ?>>URL</option>
                    <option value="popup" <?php selected($cta_settings['cta_type'], 'popup'); ?>>Popup Class</option>
                    <option value="avada" <?php selected($cta_settings['cta_type'], 'avada'); ?>>Avada Off-Canvas</option>
                </select>
            </label></p>
            <p><label>Button Value (URL, Popup Class, or Avada Off-Canvas ID):<br><input type="text" name="sfwp_cta_value" value="<?php echo esc_attr($cta_settings['cta_value']); ?>" class="regular-text" /></label></p>
            <p><label>Custom Class (optional):<br><input type="text" name="sfwp_cta_custom_class" value="<?php echo esc_attr($cta_settings['cta_custom_class']); ?>" class="regular-text" /></label></p>

            <h2>Coverage Result Success Message</h2>
            <div><label>HTML + Shortcode Message:<br>
                <textarea name="sfwp_success_message_html" rows="6" cols="50" class="large-text"><?php echo esc_textarea($cta_settings['success_message_html']); ?></textarea>
            </label></div>
            <p class="description">You can use {(sfwp_postcode)} as placeholder. HTML is allowed.</p>

            <h2>Service Boxes</h2>
            <div id="sfwp-services-wrapper">
                <?php 
                $services = get_option('sfwp_dynamic_services', array());
                if (!empty($services)):
                    foreach ($services as $index => $service):
                ?>
                    <div class="sfwp-service-item">
                        <input type="text" name="sfwp_services[<?php echo $index; ?>][icon_or_image]" value="<?php echo esc_attr($service['icon_or_image'] ?? ''); ?>" placeholder="Icon HTML or Image URL" class="regular-text" />
                        <input type="text" name="sfwp_services[<?php echo $index; ?>][name]" value="<?php echo esc_attr($service['name'] ?? ''); ?>" placeholder="Service Name" class="regular-text" />
                        <button type="button" class="button sfwp-remove-service">Remove</button>
                        <hr>
                    </div>
                <?php endforeach; endif; ?>
            </div>

            <button type="button" class="button sfwp-add-service">+ Add Service</button>

            <!-- ✅ Template outside the loop, correctly hidden -->
            <script type="text/template" id="sfwp-service-template">
                <div class="sfwp-service-item">
                    <input type="text" name="sfwp_services[__index__][icon_or_image]" placeholder="Icon HTML or Image URL" class="regular-text" />
                    <input type="text" name="sfwp_services[__index__][name]" placeholder="Service Name" class="regular-text" />
                    <button type="button" class="button sfwp-remove-service">Remove</button>
                    <hr>
                </div>
            </script>

            <p><input type="submit" name="sfwp_save_cta" class="button button-primary" value="Save Settings" /></p>
        </form>
    </div>
    <?php
}


// Shortcode
function sfwp_advanced_postcode_checker() {
    ob_start();
    ?>
    <div class="coverage-area-main">
        <div class="coverage-search-form">
            <h3>Areas We Cover For Installation</h3>
            <!-- <p></p> -->
            <div class="form-areas-search">
                <label for="postcode">Please enter the first part of your postcode only.</label>
                <input type="text" class="form-control" id="sfwp_postcode" placeholder="Example. RH5">
            </div>
            <a class="btn btn-md seach_post_code" id="sfwp_submit" href="javascript:;">Check Postcode</a>
        </div>

        <div class="coverage-result hide" id="sfwp_result_success"></div>
        <div class="coverage-error hide" id="sfwp_result_error"></div>
        <div class="loader-search hide" id="sfwp_loader">
            <div class="sfwp-css-loader"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('sfwp_checker', 'sfwp_advanced_postcode_checker');

// AJAX
function sfwp_ajax_check_postcode() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sfwp_frontend_nonce')) {
        wp_send_json_error('Invalid request.');
    }

    $input_postcode = sanitize_text_field($_POST['postcode'] ?? '');
    $postcodes = get_option('sfwp_postcodes', array());

    if (in_array($input_postcode, $postcodes)) {
        $settings = get_option('sfwp_cta_settings', array());
        $message_html = $settings['success_message_html'] ?? '<p>Experts in {(sfwp_postcode)}</p>';
        $message_html = str_replace('{(sfwp_postcode)}', '<span class="success-postcode">' . esc_html($input_postcode) . '</span>', $message_html);

        ob_start();
        ?>
        <div class="close-x close-post-code-result"><a href="javascript:;">Back</a></div>
        <div class="success-msg-heading"><?php echo $message_html; ?></div>

        <div class="service-offer-bxs">
            <?php
            $services = get_option('sfwp_dynamic_services', array());
            foreach ($services as $service) :
                $icon_or_image = $service['icon_or_image'] ?? '';
                $name = $service['name'] ?? '';
                if (empty($name)) continue;
                ?>
                <div class="offer-bx">
                    <i class="fa fa-check"></i>
                    <?php
                    if (!empty($icon_or_image)) {
                        if (strpos($icon_or_image, '<') !== false) {
                            echo $icon_or_image;
                        } else {
                            echo '<img src="' . esc_url($icon_or_image) . '" alt="' . esc_attr($name) . '">';
                        }
                    }
                    ?>
                    <h4><?php echo esc_html($name); ?></h4>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="get-in-touch-info">
            <div class="get-touch-text">You can give us a call on <strong>01737 770970</strong>, or simply Request A Quote through our website.</div>
            <?php echo sfwp_get_cta_button_html(); ?>
        </div>
        <?php
        wp_send_json_success(ob_get_clean());
    } else {
        ob_start();
        ?>
        <div class="error-face"><i class="far fa-frown"></i></div>
        <div class="error-text">
            <p class="error-content">We don’t provide installation services in this area.<!--<i class="phone-no">Tel: 01737 770 970</i>--></p>
            <div class="small-text">Please try again or get in touch below.</div>
        </div>
        <div class="retry-btn">
            <a class="btn btn-md retry-search" href="javascript:;">Retry</a>
            <a class="error-contect-link" href="/contact-us">Contact Us</a>
        </div>
        <?php
        wp_send_json_error(ob_get_clean()); // ✅ use json_error here
    }
}

add_action('wp_ajax_sfwp_check_postcode', 'sfwp_ajax_check_postcode');
add_action('wp_ajax_nopriv_sfwp_check_postcode', 'sfwp_ajax_check_postcode');
