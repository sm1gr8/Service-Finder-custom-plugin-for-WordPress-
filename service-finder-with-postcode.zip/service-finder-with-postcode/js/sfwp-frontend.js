jQuery(function ($) {
    const formArea = $('.coverage-search-form');
    const loader = $('#sfwp_loader');
    const resultSuccess = $('#sfwp_result_success');
    const resultError = $('#sfwp_result_error');
    const postcodeInput = $('#sfwp_postcode');

    function resetUI() {
        loader.addClass('hide');
        resultSuccess.addClass('hide').html('');
        resultError.addClass('hide').html('');
        formArea.removeClass('hide');
    }

    function showLoader() {
        formArea.addClass('hide');
        loader.removeClass('hide');
        resultSuccess.addClass('hide');
        resultError.addClass('hide');
    }

    function showSuccess(html) {
        loader.addClass('hide');
        resultSuccess.html(html).removeClass('hide');
    }

    function showError(html) {
        loader.addClass('hide');
        resultError.html(html).removeClass('hide');
    }

    function submitPostcode(postcode) {
        showLoader();

        $.post(sfwpAjax.ajaxurl, {
            action: 'sfwp_check_postcode',
            nonce: sfwpAjax.nonce,
            postcode: postcode
        }, function (response) {
            if (response.success) {
                showSuccess(response.data);
            } else {
                showError('<div class=\"error-text\">Something went wrong. Please try again.</div>');
            }
        });
    }

    $('#sfwp_submit').on('click', function () {
        const postcode = postcodeInput.val();
        if (postcode.trim() !== '') {
            submitPostcode(postcode);
        }
    });

    postcodeInput.on('keypress', function (e) {
        if (e.which === 13) {
            e.preventDefault();
            $('#sfwp_submit').click();
        }
    });

    // Retry button
    $(document).on('click', '.retry-search', function () {
        resetUI();
    });

    // Close success result
    $(document).on('click', '.close-post-code-result', function () {
        resetUI();
    });
});
