jQuery(function ($) {
    const modal = $('#sfwp-modal');
    const list = $('#sfwp-list');
    const pagination = $('#sfwp-pagination');
    const postcodes = sfwpData.postcodes || [];

    function renderPagination(current, totalPages) {
        const delta = 2;
        const range = [];
        const rangeWithDots = [];
        let l;

        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= current - delta && i <= current + delta)) {
                range.push(i);
            }
        }

        for (let i of range) {
            if (l) {
                if (i - l === 2) {
                    rangeWithDots.push(l + 1);
                } else if (i - l !== 1) {
                    rangeWithDots.push('...');
                }
            }
            rangeWithDots.push(i);
            l = i;
        }

        return rangeWithDots;
    }

    function renderList(page = 1, search = '') {
        const perPage = 100;
        const filtered = postcodes.filter(p => p.toLowerCase().includes(search.toLowerCase()));
        const total = filtered.length;
        const totalPages = Math.ceil(total / perPage);

        list.empty();
        const start = (page - 1) * perPage;
        filtered.slice(start, start + perPage).forEach(p => {
            list.append('<li>' + p + '</li>');
        });

        pagination.empty();
        const pages = renderPagination(page, totalPages);

        pages.forEach(p => {
            if (p === '...') {
                pagination.append('<span class="dots">...</span> ');
            } else {
                const active = (p === page) ? 'active' : '';
                pagination.append(`<a data-page="${p}" class="${active}">${p}</a> `);
            }
        });
    }

    $('#sfwp-preview-all-btn').on('click', function () {
        modal.show();
        renderList(1, '');
    });

    $('#sfwp-search').on('input', function () {
        renderList(1, $(this).val());
    });

    pagination.on('click', 'a', function () {
        renderList(parseInt($(this).data('page')), $('#sfwp-search').val());
    });

    $('.sfwp-close').on('click', function () {
        modal.hide();
    });

    $(window).on('click', function (e) {
        if ($(e.target).is(modal)) {
            modal.hide();
        }
    });
});


jQuery(function ($) {
    let serviceIndex = $('#sfwp-services-wrapper .sfwp-service-item').length || 0;

    $('.sfwp-add-service').on('click', function () {
        let template = $('#sfwp-service-template').html();
        template = template.replace(/__index__/g, serviceIndex++);
        $('#sfwp-services-wrapper').append(template);
    });

    $(document).on('click', '.sfwp-remove-service', function () {
        $(this).closest('.sfwp-service-item').remove();
    });
});

